﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet2_BDD.Models
{
    public class Adherents
    {
        public static List<Adherent> adhs = new List<Adherent>(){
            new Adherent(){Prenom="Jacques", Nom="Dupond", Email="dupond.j@gmail.com"},
            new Adherent(){Prenom="Léon", Nom="Martin", Email="leonMartin@gmail.com"},
            };
        public static List<Adherent> ObtenirAdherents()
        {
            return adhs;
        }
    }
}
