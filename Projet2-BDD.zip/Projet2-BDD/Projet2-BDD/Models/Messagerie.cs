﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet2_BDD.Models
{
    public class Messagerie
    {
        public int Id{ get; set; }
        public string Message { get; set; }
        public int IdDestinataire { get; set; }
        public virtual Adherent AdherentDestinataire { get; set; }
        public int IdEmmetteur { get; set; }
        public virtual Adherent AdherentEmmetteur { get; set; }
        public DateTime DateMessage { get; set; }

    }
}
