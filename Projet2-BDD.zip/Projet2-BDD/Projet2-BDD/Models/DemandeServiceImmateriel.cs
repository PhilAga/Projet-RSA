﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet2_BDD.Models
{
    public class DemandeServiceImmateriel
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Categorie { get; set; }
        public double Budget { get; set; }
        public DateTime DateDemande { get; set; }
        public int AdherentId { get; set; }
        public virtual Adherent Adherent { get; set; }

    }
}
