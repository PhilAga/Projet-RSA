﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet2_BDD.Models
{
    public class ContextBDD : DbContext
    {
        public DbSet<Adherent> Adherents { get; set; }
        public DbSet<DemandeServiceImmateriel> DemandeServiceImmateriels { get; set; }
        public DbSet<ProposerServiceMateriel> ProposerServiceMateriels { get; set; }
        public DbSet<Messagerie> Messageries { get; set; }
        public DbSet<Evenement_Formation> Evenement_Formations { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=localhost;user id=root;password=admin;database=RSA");
        }

        public void InitializeDb()
        {
            this.Database.EnsureDeleted();
            this.Database.EnsureCreated();
            this.Adherents.AddRange(
                new Adherent
                {
                    Prenom = "Marc",
                    Nom = "Renault",
                    Email = "marcR@gmail.com"
                },
                new Adherent
                {
                    Prenom = "Jean",
                    Nom = "Claude",
                    Email = "JC59@gmail.com"
                }
            );
            this.SaveChanges();
        }


    }

}
