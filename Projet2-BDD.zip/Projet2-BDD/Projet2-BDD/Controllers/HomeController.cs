﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Projet2_BDD.Models;
using Projet2_BDD.Dal;
using Microsoft.EntityFrameworkCore;

namespace Projet2_BDD.Controllers
{
    public class HomeController
    {
        /*
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult InscrireAdherent(int id)
        {
            if (id != 0)
            {
                using (IDal dal = new dDal())
                {
                    Adherent adh = dal.ObtenirAdherent().Where(r => r.Id == id).FirstOrDefault();
                    if (adh == null)
                    {
                        return View;
                    }
                    return View(adh);
                }
            }
            return View("Error");
        }

        //[HttpPost]
        //public IActionResult ModifierSejour(int id, string lieu, string telephone)
        //{

        //    if (id != 0)
        //    {
        //        using (Dal ctx = new Dal())
        //        {
        //            ctx.ModifierSejour(id, lieu, telephone);
        //            return RedirectToAction("ModifierSejour", new { @id = id });
        //        }
        //    }
        //    else
        //    {
        //        return View("Error");
        //    }
        //}

        [HttpPost]
        public IActionResult ModifierSejour(Sejour sejour)
        {

            if (!ModelState.IsValid)
            {
                return View(sejour);
            }


            if (sejour.Id != 0)
            {
                using (Dal ctx = new Dal())
                {
                    ctx.ModifierSejour(sejour.Id, sejour.Lieu, sejour.Telephone);
                    return RedirectToAction("ModifierSejour", new { @id = sejour.Id });
                }
            }
            else
            {
                return View("Error");
            }
        }
        */
    }
}
