﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet2_BDD.Models
{
    interface IDal : IDisposable
    {
        void DeleteCreateDatabase();

        List<Adherent> ObtenirAdherent();
        List<DemandeServiceImmateriel> ObtenirServicesImmateriel();

        List<ProposerServiceMateriel> ObtenirServicesMateriel();

        List<Evenement_Formation> ObtenirEvenement();

        int CreerAdherent( string nom, string prenom, string email);
        int CreerProposer(string type, string categorie, double prix, DateTime dateDemande);
        int CreerDemande(string type, string categorie, double budget, DateTime dateDemande);
        int CreerEvement(string titre, DateTime date, string lieu , string description, string nomOrganisateur);


    }
    
}
