﻿using Projet2_BDD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet2_BDD.Dal
{
    public class dDal : IDal
    {
        private ContextBDD _context;
        public dDal()
        {
            _context = new ContextBDD();
        }

        public void DeleteCreateDatabase()
        {
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();
        }

        public List<DemandeServiceImmateriel> ObtenirServicesImmateriel() {
            return _context.DemandeServiceImmateriels.ToList();
        }

        public List<ProposerServiceMateriel> ObtenirServicesMateriel()
        {
            return _context.ProposerServiceMateriels.ToList();
        }
        public List<Evenement_Formation> ObtenirEvenement()
        {
            return _context.Evenement_Formations.ToList();
        }
        public List<Adherent> ObtenirAdherent()
        {
            return _context.Adherents.ToList();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
        public int CreerAdherent(string nom, string prenom, string email)
        {
            Adherent adherent = new Adherent {  Nom = nom, Prenom = prenom, Email = email };
       
            _context.Adherents.Add(adherent);
            _context.SaveChanges();
            return adherent.Id;
        }

        public int CreerDemande(string type, string categorie, double budget, DateTime dateDemande)
        {
            
          DemandeServiceImmateriel demandeServiceImmateriel= new DemandeServiceImmateriel { Type=type, Categorie=categorie, Budget=budget,DateDemande= dateDemande };
            _context.DemandeServiceImmateriels.Add(demandeServiceImmateriel);
            _context.SaveChanges();
            return demandeServiceImmateriel.Id;

        }

        public int CreerProposer(string type, string categorie, double prix, DateTime dateDemande)
        {
            
            ProposerServiceMateriel proposer =new ProposerServiceMateriel{ Type = type, Categorie = categorie, Prix = prix, DateDemande = dateDemande };
            _context.ProposerServiceMateriels.Add(proposer);
            _context.SaveChanges();
            return proposer.Id;

        }

        public int CreerEvement(string titre, DateTime date, string lieu, string description, string nomOrganisateur)
        {
            
            Evenement_Formation evenement =new Evenement_Formation { Titre=titre, Date=date, Lieu=lieu, Description=description, NomOrganisateur=nomOrganisateur };
            _context.Evenement_Formations.Add(evenement);
            _context.SaveChanges();
            return evenement.Id;

        }



    }
}

