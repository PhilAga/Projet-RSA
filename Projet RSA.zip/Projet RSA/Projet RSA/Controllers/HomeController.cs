﻿using Microsoft.AspNetCore.Mvc;
using Projet_RSA.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet_RSA.Controllers
{
    public class HomeController : Controller
    {
        private IDal dal;

        public HomeController()
        {
            this.dal = new Dal();
        }
        public IActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Services()
        {
            return View();

        }

        public ActionResult Contact()
        {
            return View();
        }
    }
}
