﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet_RSA.Controllers
{
    public class PaymentController : Controller
    {
        // private int amount = 100;
        public IActionResult Payer()
        {
            // ViewBag.PaymentAmount = amount;
            return View();
        }


        //public IActionResult Charge(string stripeEmail, string stripeToken)
        //{

        //    var customers = new CustomerService();
        //    var charges = new ChargeService();
        //    var customer = customers.Create(new CustomerCreateOptions
        //    {
        //        Email = stripeEmail,
        //        SourceToken = stripeToken,

        //    });

        //    var charge = charges.Create(new ChargeCreateOptions
        //    {

        //        Amount = 50,
        //        Currency = "Euro",
        //        Description = "Paiement de l'abonnement",
        //        CustomerId = customer.Id,
        //        ReceiptEmail = stripeEmail,
        //        Metadata = new Dictionary<string, string>() {
        //                    { "OrderId", "111" },
        //                    {"Postcode" , "ppp233"} }

        //    });
        //    if (charge.Status == "succeeded")
        //    {
        //        string BalanceTransactionId = charge.BalanceTransactionId;
        //        return View();
        //    }
        //    else
        //    {
        //    }
        //    return View();
        //}
    }
}
