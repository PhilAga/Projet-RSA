﻿using Microsoft.AspNetCore.Mvc;
using Projet_RSA.Data;
using Projet_RSA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet_RSA.Controllers
{
    public class AdherentController : Controller
    {
        public IActionResult InscrireAdherent()
        {
            /*
            if (id != 0)
            {
                using (IDal dal = new dDal())
                {
                    Adherent adh = dal.ObtenirAdherent().Where(r => r.Id == id).FirstOrDefault();
                    if (adh == null)
                    {
                        return View();
                    }
                    return View(adh);
                }
            }
            return View("Error");
            */
            return View();
        }

        [HttpPost]
        public IActionResult InscrireAdherent(Adherent adh)
        {

            if (!ModelState.IsValid)
            {
                return View(adh);
            }



            using (Dal ctx = new Dal())
            {
                ctx.CreerAdherent(adh.Nom, adh.Prenom, adh.Email);
                //return RedirectToAction("ObtenirAdherent");
                return RedirectToAction("InscrireAdherent");
            }
        }
        /*
        public IActionResult ListeAdherents()
        {
            List<Adherent> adhs = Adherents.ObtenirAdherents();
            ViewData["Adherents"] = adhs;
            return View();
        }
        */

        public IActionResult Index()
        {
            return View();
        }

        /*  public IActionResult Liste()
          {

              List<Tuto> tutos = new List<Tuto>()
          {
              new Tuto{Id = 1, Titre="title1" , Lien="Lien1"},
              new Tuto {Id = 2, Titre="title2" , Lien="Lien2" },
              new Tuto { Id = 3, Titre="title3" , Lien="Lien3"}
          };

              return View(tutos);
          }

          public IActionResult Forum()
          {
              return View();
          }*/
    }
}
