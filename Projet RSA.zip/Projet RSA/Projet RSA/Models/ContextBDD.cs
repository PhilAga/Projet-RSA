﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet_RSA.Models
{
    public class ContextBDD : DbContext
    {
        public DbSet<Utilisateur> Utilisateurs { get; set; }
        public DbSet<Adherent> Adherents { get; set; }
        public DbSet<DemandeServiceImmateriel> DemandeServiceImmateriels { get; set; }
        public DbSet<ProposerServiceMateriel> ProposerServiceMateriels { get; set; }
        public DbSet<Messagerie> Messageries { get; set; }
        public DbSet<Evenement_Formation> Evenement_Formations { get; set; }
        public DbSet<Post> Posts { get; set; }
        public DbSet<Commentaire> Comments { get; set; }
        public DbSet<Tag> Tags { get; set; }
        public DbSet<AppUser> AppUsers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=localhost;user id=root;password=rrrrr;database=RSA");
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Messagerie>().HasOne<AppUser>(a => a.AppUser).
                WithMany(d => d.Messageries).HasForeignKey(d => d.IdAdherent);
        }
        public void InitializeDb()
        {
            this.Database.EnsureDeleted();
            this.Database.EnsureCreated();
            this.Messageries.AddRange(
                new Messagerie
                {
                    Id = 1,
                    UserName = "Disney",
                    Message = "000000000"
                },
                new Messagerie
                {
                    Id = 2,
                    UserName = "Chambord",
                    Message = "111111111"
                }
            );
            this.SaveChanges();
        }
    }
}
