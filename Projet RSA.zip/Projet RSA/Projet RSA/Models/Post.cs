﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Projet_RSA.Models
{
    //L’idée sera de créer dans la classe Post une liste de tags et dans la classe Tag une liste de Post(articles).
    public class Post
    {
        public int ID { get; set; }

        // Le pseudo de l'auteur

        [Required(AllowEmptyStrings = false)]
        [StringLength(128)]
        [RegularExpression(@"^[^,\.\^]+$")]
        [DataType(DataType.Text)]
        public string Pseudo { get; set; }


        /// Le titre de Post

        [Required(AllowEmptyStrings = false)]
        [StringLength(128)]
        [DataType(DataType.Text)]
        public string Titre { get; set; }


        //Le contenu de l'article

        [Required(AllowEmptyStrings = false)]
        [DataType(DataType.MultilineText)]
        public string Contenu { get; set; }


        // Le chemin de l'image

        public string ImageName { get; set; }

        public virtual List<Commentaire> Comments { get; set; }
        public enum TypeAnnonce
        {
            DemandeService,
            PropositionService
        }
    }
}
