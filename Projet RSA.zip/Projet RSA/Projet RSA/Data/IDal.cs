﻿using Projet_RSA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projet_RSA.Data
{
    interface IDal : IDisposable
    {
        void DeleteCreateDatabase();

        List<Adherent> ObtenirAdherent();
        List<DemandeServiceImmateriel> ObtenirServicesImmateriel();

        List<ProposerServiceMateriel> ObtenirServicesMateriel();

        List<Evenement_Formation> ObtenirEvenement();
        List<Tag> ObtenirTag();
        List<Commentaire> ObtenirCommentaire();
        public List<Post> ObtenirPost();
        int CreerAdherent(string nom, string prenom, string email);
        int CreerProposer(string type, string categorie, double prix, DateTime dateDemande);

        int CreerDemande(string type, string categorie, double budget, DateTime dateDemande);
        int CreerEvement(string titre, DateTime date, string lieu, string description, string nomOrganisateur);
        object ObtenirUtilisateur(string userId);
        int CreerPost(string Pseudo, string Titre, string Contenu, string ImageName);
        int CreerCommentaire(string email, string pseudo, string contenu, DateTime publication);
        int CreerTag(string Name, string Slug);
        Utilisateur AjouterUtilisateur(string prenom, string nom, string email, string password);
        Utilisateur Authentifier(string prenom, string password);
    }
}
