﻿using Projet_RSA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Projet_RSA.Data
{
    public class Dal : IDal
    {
        private ContextBDD _context;



        public Dal()
        {
            _context = new ContextBDD();
        }

        public void DeleteCreateDatabase()
        {
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();
        }


        // addeed for authentification

        public Utilisateur AjouterUtilisateur(string prenom, string nom, string email, string password)
        {
            string motDePasse = EncodeMD5(password);
            Utilisateur user = new Utilisateur() { Prenom = prenom, Nom = nom, Email = email, Password = motDePasse };
            this._context.Utilisateurs.Add(user);
            this._context.SaveChanges();

            return user;
        }

        public Utilisateur Authentifier(string prenom, string password)
        {
            string motDePasse = EncodeMD5(password);
            Utilisateur user = this._context.Utilisateurs.FirstOrDefault(u => u.Prenom == prenom && u.Password == motDePasse);
            return user;
        }

        public Utilisateur ObtenirUtilisateur(int id)
        {
            return this._context.Utilisateurs.FirstOrDefault(u => u.Id == id);
        }

        public Utilisateur ObtenirUtilisateur(string idStr)
        {
            int id;
            if (int.TryParse(idStr, out id))
            {
                return this.ObtenirUtilisateur(id);
            }
            return null;
        }

        private string EncodeMD5(string motDePasse)
        {
            string motDePasseSel = "Automobile" + motDePasse + "ASP.NET MVC";
            return BitConverter.ToString(new MD5CryptoServiceProvider().ComputeHash(ASCIIEncoding.Default.GetBytes(motDePasseSel)));
        }

        public List<DemandeServiceImmateriel> ObtenirServicesImmateriel()
        {
            return _context.DemandeServiceImmateriels.ToList();
        }

        public List<ProposerServiceMateriel> ObtenirServicesMateriel()
        {
            return _context.ProposerServiceMateriels.ToList();
        }
        public List<Evenement_Formation> ObtenirEvenement()
        {
            return _context.Evenement_Formations.ToList();
        }
        public List<Adherent> ObtenirAdherent()
        {
            return _context.Adherents.ToList();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
        public int CreerAdherent(string nom, string prenom, string email)
        {
            Adherent adherent = new Adherent { Nom = nom, Prenom = prenom, Email = email };

            _context.Adherents.Add(adherent);
            _context.SaveChanges();
            return adherent.Id;
        }
        public int CreerPost(string Pseudo, string titre, string contenu, string imageName)
        {
            Post post = new Post { Pseudo = Pseudo, Titre = titre, Contenu = contenu, ImageName = imageName };
            _context.Posts.Add(post);
            _context.SaveChanges();
            return post.ID;
        }


        public int CreerDemande(string type, string categorie, double budget, DateTime dateDemande)
        {

            DemandeServiceImmateriel demandeServiceImmateriel = new DemandeServiceImmateriel { Type = type, Categorie = categorie, Budget = budget, DateDemande = dateDemande };
            _context.DemandeServiceImmateriels.Add(demandeServiceImmateriel);
            _context.SaveChanges();
            return demandeServiceImmateriel.Id;

        }

        public int CreerProposer(string type, string categorie, double prix, DateTime dateDemande)
        {

            ProposerServiceMateriel proposer = new ProposerServiceMateriel { Type = type, Categorie = categorie, Prix = prix, DateDemande = dateDemande };
            _context.ProposerServiceMateriels.Add(proposer);
            _context.SaveChanges();
            return proposer.Id;

        }

        public int CreerEvement(string titre, DateTime date, string lieu, string description, string nomOrganisateur)
        {

            Evenement_Formation evenement = new Evenement_Formation { Titre = titre, Date = date, Lieu = lieu, Description = description, NomOrganisateur = nomOrganisateur };
            _context.Evenement_Formations.Add(evenement);
            _context.SaveChanges();
            return evenement.Id;

        }
        public List<Tag> ObtenirTag()
        {
            return _context.Tags.ToList();
        }
        public List<Post> ObtenirPost()
        {
            return _context.Posts.ToList();
        }
        public List<Commentaire> ObtenirCommentaire()
        {
            return _context.Comments.ToList();
        }
        public int CreerTag(string name, string slug)
        {
            Tag tag = new Tag { Name = name, Slug = slug };
            _context.Tags.Add(tag);
            _context.SaveChanges();
            return tag.ID;
        }
        public int CreerCommentaire(string email, string pseudo, string contenu, DateTime publication)
        {
            Commentaire commentaire = new Commentaire { Email = email, Pseudo = pseudo, Contenu = contenu, Publication = publication };
            _context.Comments.Add(commentaire);
            _context.SaveChanges();
            return commentaire.ID;
        }

        object IDal.ObtenirUtilisateur(string userId)
        {
            throw new NotImplementedException();
        }
    }
}
